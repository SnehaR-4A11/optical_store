<?php
include('dbcon.php');
$id=$_POST['id'];
$brand_id=$_POST['t1'];
$gender=$_POST['g1'];
$frame_color=$_POST['c1'];
$size=$_POST['s1'];
$frame_type=$_POST['f1'];
$frame_shape=$_POST['s1'];
$frame_material=$_POST['m1'];
$photo=$_FILES['file']['name'];
$prize=$_POST['p1'];
$stock=$_POST['q1'];
$description=$_POST['d1'];


if(!empty($_FILES['file']['name']))
{

$ss="update product set brand_id='$brand_id',gender='$gender',frame_color='$frame_color',size='$size',frame_type='$frame_type',frame_shape='$frame_shape',frame_material='$frame_material',photo='$photo',description='$description',prize='$prize' where id='$id'";
$rs=mysqli_query($con,$ss);

}

else
{
$ss="update product set brand_id='$brand_id',gender='$gender',frame_color='$frame_color',size='$size',frame_type='$frame_type',frame_shape='$frame_shape',frame_material='$frame_material',stock='$stock',description='$description',prize='$prize' where id='$id'";
$rs=mysqli_query($con,$ss);	

//echo $ss;
}
?>
<script>
	alert("Updated Successfully");
	document.location="product_view.php";
</script>