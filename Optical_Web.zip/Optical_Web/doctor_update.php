<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('header.php');?>
    
   <h1 align="center">Doctor Details</h1>
	
	<style>
	input[type="register"]
	{
		background-color:blue;
	}
</style>
<body bgcolor="pink">

	<form method="post" action="doctor_db.php" enctype="multipart/form-data">
		<?php
		$id=$_GET['id'];
		include('dbcon.php');
		$ss="select * from doctor where id='$id' ";
		$rs=mysqli_query($con,$ss);
		$row=mysqli_fetch_array($rs);
		?>
		<table  align="center" width="300" height="300">
        <input type="hidden" name="id" value="<?php echo $id;?>">
		<tr>
			<td><b>Doctor_name</b></td>
			<td><input type="text"name="d1" value="<?php echo $row['doctor_name'];?>"required></td>
			</tr>
			<tr>
			<td><b>Specialist_in</b></td>
			<td><input type="text" name="d2" value="<?php echo $row['specialist_in'];?>"required></td>
			</tr>
			<tr>
				<td><b>Experience</b></td>
				<td><input type="text" name="d3" value="<?php echo $row['experience'];?>"required></td>
			</tr>
		<tr>
			<td><b>Photo</b></td>
			<td><input type="file" name="file" value="<?php echo $row['photo'];?>" required></td>
		</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="book"></td>
			</tr>
			<table>
                      

			 </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>