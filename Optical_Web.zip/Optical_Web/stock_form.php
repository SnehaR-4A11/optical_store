<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('header.php');?>
    
   <h1 align="center"><b>Stock</b></h1>

	<form method="post" action="stock_insert.php">
		<table align="center"width="300" height="300">
		<tr>
			<td><b>Pid</b></td>
			<td><input type="text"name="t1"required></td>
			</tr>
			<tr>
				<td><b>Total_stock</b></td>
				<td><input type="text" name="c1"required></td>
			</td>
		</tr>
			<tr>
				<td><b>Current_stock</b></td>
				<td><input type="text" name="p1" required></td>
			</tr>
			<td></td>
				<td><input type="submit"></td>
			</tr>
			<table></table>
		</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
			