<?php include('admin_header.php');?>
    
   <h1 align="center">DateWise Order Details</h1>
   <hr>

	<form method="post" action="order_view_datewise2.php" enctype="multipart/form-data">
		<table  align="center" width="500" height="400">

		<tr>
			<td><b>Date</b></td>
			<td><input type="date" name="t1" required></td>
			</tr>

		
			<tr>
				<td></td>
				<td><input type="submit" value="book"></td>
			</tr>
			<table>
                      

			 </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>