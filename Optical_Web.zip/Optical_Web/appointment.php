<?php include('user_header.php');?>
    
   <h1 align="center"> Take an Appointment </h1>
   <hr>
	<table width="900" border='1' align="center">

		<tr style="background-color:blue;color:white;height:35px;">	
		<td>doctor_name</td>
		<td>specialist_in</td>
		<td>experience</td>
		<td>photo</td>
		<td align="center" style="background-color:red">Action</td>
	</tr>	
<?php
include('dbcon.php');
$sql="select * from doctor";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['doctor_name'];?></td>
		<td><?php echo $row['specialist_in'];?></td>
		<td><?php echo $row['experience'];?></td>
		
		<td><img src="upload/<?php echo $row['photo'];?>" width="100" height="100"></td>
		
		<td align="center"><a href="app_form.php?id=<?php echo $row['id'];?>">Take Appointment </a></td>
		</tr>
		<?php
}
?>
</table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>