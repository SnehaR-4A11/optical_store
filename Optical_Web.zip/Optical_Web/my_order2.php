<?php session_start(); ?>
<?php include('user_header.php');?>
    
   <h1 align="center">My Order</h1>
   <hr>

	<table align="center" width="900" border='1'>

		<tr style="background-color:blue;color:white">
		<td><b>Order_date</b></td>
		<td><b>Product Name</b></td>
		<td><b>Qty</b></td>
		<td><b>Unit Price</b></td>
		<td><b>Total</b></td>
		<td><b>Order status</b></td>
		<td><b>Payment status</b></td>
		
		<td colspan="2" align="center" style="background-color:red;">Action</td>
	</tr>	
<?php

$u=$_SESSION['t1'];
$oid=$_GET['id'];
include('dbcon.php');
$sql="select * from order_details where cus_id='$u' and order_no='$oid'";
//echo $sql;
$rs=mysqli_query($con,$sql);
$total=0;
while($row=mysqli_fetch_array($rs))
{
	  $total+=$row['total'];
	  $id=$row['id'];
	?>
	<tr>
		
		<td><?php echo $row['order_date'];?></td>
		<td><?php echo $row['pname'];?></td>
		<td><?php echo $row['qty'];?></td>
		<td><?php echo $row['unit_price'];?></td>
		<td><?php echo $row['total'];?></td>
		<td><?php echo $row['order_status'];?></td>
		<td><?php echo $row['payment_status'];?></td>

		<?php 
      $n="select * from order_details where id='$id' and order_status='confirmed'";
      $n1=mysqli_query($con,$n);
      $n2=mysqli_fetch_array($n1);
      if(empty($n2))
      {

		?>
		<td><a href="order_del.php?id=<?php echo $row['id'];?>">Cancel Order</a></td>

		<?php 
	   }
	   else
	   {
	   	?>
	   	<td style="color:blue;">Order Confirmed</td>
	   	<?php 
	   }?>

		</tr>
<?php
}
?>
</table>

<?php 
      $m="select * from order_details where order_no='$oid' and order_status='confirmed'";
      $m1=mysqli_query($con,$m);
      $m2=mysqli_fetch_array($m1);
      if(empty($m2))
      {

		?>
       <p align="center"><a href="confirm_order.php?id=<?php echo $oid;?>">Confirm Order</a></p>
       <?php
       }
       else
	  {

	  	   $q="select * from order_details where order_no='$oid' and order_status='confirmed' and payment_status='Paid'";
      $q1=mysqli_query($con,$q);
      $q2=mysqli_fetch_array($q1);
        if(empty($q2))
        {


	  	?>
     <hr>
     <p align="center"><a href="payment.php?id=<?php echo $oid;?>&price=<?php echo $total;?>" style="color:red;"> Pay Now </a> </p>
	  	<?php
	    }
	     else
	     {
	     	?>
            <h3 align="center" style="color:red;"> Payment Status: Paid </h3>
	     	<?php
	     }
	  }
	?>
</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>