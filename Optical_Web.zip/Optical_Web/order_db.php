<?php
include('dbcon.php');
$id=$_POST['id'];
$cus_id=$_POST['t1'];
$order_date=$_POST['c1'];
$pid=$_POST['p1'];
$order_status=$_POST['o1'];
$payment_status=$_POST['r1'];
$delivered_status=$_POST['q1'];
$ss="update order_details set cus_id='$cus_id',order_date='$order_date',pid='$pid',order_status='$order_status',payment_status='$payment_status',delivered_status='$delivered_status' where id='$id'";
$rs=mysqli_query($con,$ss);
?>
<script>
	alert("Updated Successfully");
	document.location="order_view.php";
</script>