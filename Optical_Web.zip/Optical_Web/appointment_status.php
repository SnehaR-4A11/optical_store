<?php session_start();?>
<?php include('user_header.php');?>
<h1 align="center"> Appointment Status</h1>
<hr>
	<table align="center" width="900" border='1'>
		<tr style="background-color:blue;color:white">	
		<td><b>Doctor Id</b></td>
		<td><b>Customer Id</b></td>
		<td><b>Date</b></td>
		<td><b>Timing</b></td>
		<td><b>Status</b></td>
		<td align="center" style="background-color:red">Action</td>
	</tr>	
<?php
$u=$_SESSION['t1'];
include('dbcon.php'); 
$sql="select * from appointment where cus_id='$u'";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['doctor_id'];?></td>
		<td><?php echo $row['cus_id'];?></td>
		<td><?php echo $row['app_required_date'];?></td>
		<td><?php echo $row['app_timming'];?></td>
		<td><?php echo $row['app_status'];?></td>

		<td><a href="view_prescription.php?id=<?php echo $row['id'];?>"> View Prescription </a></td>
		</tr>
		<?php
}
?>
</table>
</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>