<?php include('header.php');?>
    
   <h1>order details</h1>

	<form method="post" action="order_db.php">
		<?php
		$id=$_GET['id'];
		include('dbcon.php');
		$ss="select * from register where id='$id' ";
		$rs=mysqli_query($con,$ss);
		$row=mysqli_fetch_array($rs);
		?>
		<table width="300" height="300">
			<input type="hidden" name="id" value="<?php echo $id;?>">
		
		<tr>
			<td>cus_id</td>
			<td><input type="text" name="t1" value="<?php echo $row['cus_id'];?>" required>
			</tr>
			<tr>
				<td>order_date</td>
				<td><input type="date" name="c1" value="<?php echo $row['order_date'];?>" required>
			</td>
		</tr>
			<tr>
				<td>pid</td>
				<td><input type="text" name="p1" value="<?php echo $row['pid'];?>" required></td>
			</tr>
			<tr>
			<td>order_status</td>
			<td><input type="text"name="o1"  value="<?php echo $row['order_status'];?>" required>
			</tr>
			<tr>
				<td>payment_status</td>
				<td><input type="text" name="r1" value="<?php echo $row['payment_status'];?>" required>
			</td>
		</tr>
			<tr>
				<td>delivered_status</td>
				<td><input type="text" name="q1" value="<?php echo $row['delivered_status'];?>" required></td>
			</tr>
			<td></td>
				<td><input type="submit"></td>
			</tr>
			<table></table>
				  </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
					