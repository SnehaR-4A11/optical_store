<?php
include('dbcon.php');
$brandname=$_POST['s1'];
$sql="insert into brandname(brandname)values('$brandname')";
$rs=mysqli_query($con,$sql);
if($rs)
{
	?>
	 <script>
	 	alert("inserted successfully");
	 	document.location="brandname.php";
	 </script>
<?php
}
else
{
	echo"not inserted";
}
?>
	