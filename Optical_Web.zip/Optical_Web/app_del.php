<?php
$id=$_GET['id'];
include('dbcon.php');
$sql="delete from appointment where id='$id'";
mysqli_query($con,$sql);
?>
<script>
	alert("deleted successfully");
	document.location="app_view.php";
</script>