<?php include('admin_header.php');?>
    
   <h1 align="center">List Of Orders</h1>

	<table align="center" width="900" border='1'>

		<tr style="background-color:blue;color:white">	
			<td><b>Order Id</b></td>
		<td><b>Customer_id</b></td>
		<td><b>Order_date</b></td>
		<td><b>Product Name</b></td>
		<td><b>Payment_status</b></td>
		<td><b>Total Amount</b></td>
		
	</tr>	
<?php
$date=$_POST['t1'];
include('dbcon.php');
$sql="select * from order_details where order_status='confirmed' and order_date='$date'";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['order_no'];?></td>
		<td><?php echo $row['cus_id'];?></td>
		<td><?php echo $row['order_date'];?></td>
		<td><?php echo $row['pname'];?></td>
		<td><?php echo $row['payment_status'];?></td>
		<td><?php echo $row['total'];?></td>
		
		
		</tr>
		<?php
}
?>
</table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>