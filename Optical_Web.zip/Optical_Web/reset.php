<html>
<body bgcolor="black" text="white">
	<form method="post" action="log_insert.php">
	<table width="300" height="300">
		<tr>
			<td>new password</td>
			<td><input type="password" name="r1" required></td>
		</tr>
		<tr>
			<td>confirm password</td>
			<td><input type="password" name="t2" required></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="reset password"></td>
		</tr>
	</table></form></body></html>