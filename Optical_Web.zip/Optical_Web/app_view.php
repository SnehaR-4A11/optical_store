<?php include('doctor_header.php');?>
    
   <h1 align="center">Appointment Details</h1>
	<table align="center" width="900" border='1'>

		<tr style="background-color:lightgreen;color:white">	
		<td><b>Doctor_id</b></td>
		<td><b>Customer_id</b></td>
		<td><b>App_required_date</b></td>
		<td><b>App_status</b></td>
		<td><b>App_timming</b></td>
		<td colspan="2" align="center" style="background-color:red">Action</td>
	</tr>	
<?php
include('dbcon.php'); 
$sql="select * from appointment";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['doctor_id'];?></td>
		<td><?php echo $row['cus_id'];?></td>
		<td><?php echo $row['app_required_date'];?></td>
		<td><?php echo $row['app_status'];?></td>
		<td><?php echo $row['app_timming'];?></td>
		<td><a href="app_del.php?id=<?php echo $row['id'];?>"><i class="fa fa-trash" style="color:red"></a></td>
		<td><a href="app_update.php?id=<?php echo $row['id'];?>"><i class="fa fa-edit" style="color:purple"></a></td>
		</tr>
		<?php
}
?>
</table>
</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>