<html>
<body >
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('header.php');?>
    
   <h1 align="center; color:black;">Customer Registration</h1>

	<style>
	input[type="register"]
	{
		background-color:blue;
	}
</style>


	<form method="post" action="creg_insert.php" style="background-color:red;">
		<table  align="center" width="350" height="350">

		<tr>
			<td ><b>First_name</b></td>
			<td><input type="text"name="t1"required pattern="[A-Za-z]{1,15}" autocomplete="off"></td>
			</tr>
			<tr>
			<td><b>Last_name</b></td>
			<td><input type="text" name="t2"required pattern="[A-Za-z]{1,15}" autocomplete="off"></td>
			</tr>
			<tr>
				<td><b>DOB</b></td>
				<td><input type="date" name="t3"required max="<?php echo date('Y-m-d');?>"</td>
				</td>
				
			<tr>
			<td> <b>City</b> </td>
			
               <td><select name="s1">
			     <option value="dharwad"> Dharwad</option>
			     	<option value="hubli"> Hubli</option>
			        <option value="belgavi"> Belgavi</option>
			    </select></td>
			</tr>
			<tr>
				<td><b>Landmark</b></td>
				<td><input type="text" name="l1" autocomplete="off"></td>
			</tr>
		<tr>
			<td><b>Address</b></td>
			<td> <input type="text" name="a1" autocomplete="off"></td>

		</tr>
		
			<tr>
				<td><b>Pincode</b></td>
				<td><input type="number" name="p1"></td>
			</tr>
			<tr>
				<td><b>Contact</b></td>
				<td><input type="text" name="c1" required pattern="[6-9]{1}[0-9]{9}" title="enter valid number"></td>
			</tr>
			<tr>
				<td><b>Email</b></td>
				<td><input type="Email" name="e1"required></td>
			</tr>
			<tr>
		<td><b>Password</b></td>
		<td><input type="Password" name="t7" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="must contain atleast one number  and one uppercase and lowercase letter, and atleast 8 or more characters"  required></td>
	</tr>
	<tr>
		<td><b>Confirm Password</b></td>
		<td><input type="Password" name="t8" placeholder="confirmPassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="must contain atleast one number  and one uppercase and lowercase letter, and atleast 8 or more characters" required></td>
	</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Register"></td>
			</tr>
			<table>
			</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>