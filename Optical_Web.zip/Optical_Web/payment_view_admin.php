<?php include('admin_header.php');?>
    
   <h1 align="center">Payment</h1>

	<table align="center" width="700" border='1'>

		<tr style="background-color:lightgreen;color:white">	
		<td><b>Order_id</b></td>
		<td><b>Amount</b></td>
		<td><b>Payment_date</b></td>
		
	</tr>	
<?php
include('dbcon.php');
$sql="select * from payment";
$rs=mysqli_query($con,$sql);
$total=0;
while($row=mysqli_fetch_array($rs))
{
	 $total+=$row['amount'];
	?>
	<tr>
		<td><?php echo $row['order_id'];?></td>
		<td><?php echo $row['amount'];?></td>
		<td><?php echo $row['payment_date'];?></td>
		</tr>
		<?php
}
?>
<tr style="background-color:blue;color:white;"> 
  <td> Total </td>
  <td><?php echo $total;?> </td>
  <td> </td>
</tr>
</table> 

</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>