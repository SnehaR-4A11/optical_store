-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2022 at 01:12 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `optical`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_prescription`
--

CREATE TABLE `add_prescription` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `cust_id` varchar(100) NOT NULL,
  `prescription` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_prescription`
--

INSERT INTO `add_prescription` (`id`, `request_id`, `cust_id`, `prescription`) VALUES
(1, 6, 'sneha@gmail.com', 'gfjhgjgjg');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctor_id` varchar(40) NOT NULL,
  `cus_id` varchar(50) NOT NULL,
  `app_required_date` date NOT NULL,
  `app_status` varchar(10) NOT NULL,
  `app_timming` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctor_id`, `cus_id`, `app_required_date`, `app_status`, `app_timming`) VALUES
(6, 'Harish', 'sneha@gmail.com', '2022-07-24', 'accepted', '11am');

-- --------------------------------------------------------

--
-- Table structure for table `brandname`
--

CREATE TABLE `brandname` (
  `id` int(11) NOT NULL,
  `brandname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brandname`
--

INSERT INTO `brandname` (`id`, `brandname`) VALUES
(2, 'jacobes');

-- --------------------------------------------------------

--
-- Table structure for table `creg`
--

CREATE TABLE `creg` (
  `id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `city` varchar(10) NOT NULL,
  `landmark` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `pincode` int(6) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `creg`
--

INSERT INTO `creg` (`id`, `firstname`, `lastname`, `city`, `landmark`, `address`, `pincode`, `contact`, `email`) VALUES
(5, 'sneha', 'soppin', 'dharwad', 'setter colony', 'indira nagar', 50008, '6363578996', 'sne@gmail.com'),
(6, '', '', 'jacobes', '', '', 0, '', ''),
(7, '', '', '', '', '', 0, '', ''),
(8, 'sneha', 'soppin', 'hubli', 'shetter colony', 'indira nagar', 58001, '9902768512', 'varsg@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(11) NOT NULL,
  `doctor_name` varchar(20) NOT NULL,
  `specialist_in` varchar(20) NOT NULL,
  `experience` int(5) NOT NULL,
  `photo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `doctor_name`, `specialist_in`, `experience`, `photo`) VALUES
(15, 'Harish', 'Eye', 7, 'bp1.png');

-- --------------------------------------------------------

--
-- Table structure for table `lens_product`
--

CREATE TABLE `lens_product` (
  `id` int(11) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `lens_type` varchar(30) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lens_product`
--

INSERT INTO `lens_product` (`id`, `brand`, `lens_type`, `price`) VALUES
(1, 'Bifocal', 'Glass', 350),
(2, 'Bifocal', 'Fiber', 800),
(3, 'Executive', 'Glass', 500),
(4, 'Executive', 'Fiber', 2000),
(5, 'Progressive', 'Glass', 4500),
(6, 'Progressive', 'Fiber', 3000),
(7, 'D-Focal', 'Glass', 500),
(8, 'D-Focal', 'Fiber', 800),
(9, 'Blux Max', 'Fiber', 2000),
(10, 'Anti Reflection', 'Glass', 700),
(11, 'Single Vision', 'Glass', 250),
(12, 'Single Vision', 'Fiber', 400);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  `usertype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `usertype`) VALUES
(1, 'surebansuman2001@gmail.com', 'Sne12345', 'admin'),
(8, 'customer', 'Cus12345', 'customer'),
(11, 'sneha@gmail.com', 'Sneha098', 'customer'),
(12, 'Harish', 'Ha123456', 'doctor');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `cus_id` varchar(50) NOT NULL,
  `order_date` date NOT NULL,
  `pid` int(20) NOT NULL,
  `order_status` varchar(20) NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `delivered_status` varchar(20) NOT NULL,
  `pname` varchar(40) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `order_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `cus_id`, `order_date`, `pid`, `order_status`, `payment_status`, `delivered_status`, `pname`, `qty`, `unit_price`, `total`, `order_no`) VALUES
(9, 'sneha@gmail.com', '2022-07-24', 19, 'confirmed', 'Paid', 'progressing', '13', 1, 3000, 3000, 2486),
(10, 'sneha@gmail.com', '2022-07-24', 1, 'confirmed', 'Paid', 'progressing', 'Bifocal', 1, 350, 350, 2486);

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `id` int(11) NOT NULL,
  `otp` int(4) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `otp`
--

INSERT INTO `otp` (`id`, `otp`, `status`) VALUES
(25, 5739, 'active'),
(26, 9245, 'active'),
(27, 8715, 'active'),
(28, 6134, 'active'),
(29, 9602, 'active'),
(30, 5096, 'active'),
(31, 2537, 'active'),
(32, 2733, 'active'),
(33, 8934, 'active'),
(34, 6814, 'active'),
(35, 4749, 'active'),
(36, 4781, 'inactive');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `amount` int(20) NOT NULL,
  `payment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `order_id`, `amount`, `payment_date`) VALUES
(3, '2486', 3350, '2022-07-24');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `brand_id` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `frame_color` varchar(20) NOT NULL,
  `size` varchar(10) NOT NULL,
  `frame_type` varchar(20) NOT NULL,
  `frame_shape` varchar(20) NOT NULL,
  `frame_material` varchar(20) NOT NULL,
  `photo` varchar(30) NOT NULL,
  `prize` varchar(20) NOT NULL,
  `description` varchar(20) NOT NULL,
  `stock` int(11) NOT NULL,
  `remaining_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `brand_id`, `gender`, `frame_color`, `size`, `frame_type`, `frame_shape`, `frame_material`, `photo`, `prize`, `description`, `stock`, `remaining_stock`) VALUES
(19, '13', 'male', 'blue', 'cateye', 'rimmed', 'cateye', 'stainlesssteel', 'eye1.jpg', '3000', 'bjh', 30, 29);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `Id` int(20) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `city` varchar(10) NOT NULL,
  `landmark` varchar(20) NOT NULL,
  `address` varchar(30) NOT NULL,
  `pincode` int(6) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Id`, `firstname`, `lastname`, `city`, `landmark`, `address`, `pincode`, `contact`, `email`) VALUES
(17, 'vini', 'badiger', 'dharwad', 'shetter colony', 'indira nagar', 58008, '9380136132', 'vinodabadiger0@gmail'),
(18, 'varshini', 'Nidagundimath', 'dharwad', 'Iti college', 'JSS campus', 580004, '7019096714', 'varshininidagundimat'),
(19, 'varshini', 'Nidagundimath', 'dharwad', 'Iti college', 'JSS campus', 58004, '7760143639', 'varhininidagundimath'),
(20, 'sneha', 'sopppin', 'belgavi', 'near lions school', 'basaweshwar nagar', 580004, '6363846670', 'snehasoppin@gmail.co'),
(21, 'sneha', 'sopppin', 'belgavi', 'near lions school', 'basaweshwar nagar', 580004, '6363846670', 'snehasoppin@gmail.co'),
(22, 'sneha', 'soppin', 'hubli', 'shetter colony', 'indira nagar', 58001, '6363846670', 'snehasoppin@gmail.co'),
(23, 'sneha', 'soppin', 'hubli', 'shetter colony', 'indira nagar', 58001, '6363846670', 'snehasoppin@gmail.co'),
(24, 'sneha', 'soppin', 'hubli', 'ofuho', 'indira nagar', 58001, '6363846670', 'sneha@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `pid` int(10) NOT NULL,
  `total_stock` int(20) NOT NULL,
  `current_stock` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `pid`, `total_stock`, `current_stock`) VALUES
(2, 101, 100, 90);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_prescription`
--
ALTER TABLE `add_prescription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brandname`
--
ALTER TABLE `brandname`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `creg`
--
ALTER TABLE `creg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lens_product`
--
ALTER TABLE `lens_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otp`
--
ALTER TABLE `otp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_prescription`
--
ALTER TABLE `add_prescription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `brandname`
--
ALTER TABLE `brandname`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `creg`
--
ALTER TABLE `creg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `lens_product`
--
ALTER TABLE `lens_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `otp`
--
ALTER TABLE `otp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
