<?php
include('dbcon.php');
$username=$_POST['t1'];
$password=$_POST['t2'];
$usertype=$_POST['t3'];
$sql="insert into login(username,password,usertype)values('$username','$password','$usertype')";
$rs=mysqli_query($con,$sql);
if($rs)
{
	echo"inserted successfully";
}
else
{
	echo"not inserted";
}
?>