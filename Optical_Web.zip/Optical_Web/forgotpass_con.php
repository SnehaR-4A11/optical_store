<?php
include('dbcon.php');
session_start();
$username=$_POST['t1'];
$_SESSION['t1']=$username;
$ss="select * from login where username='$username'";
$rs=mysqli_query($con,$ss);
$row=mysqli_fetch_array($rs);
 if(empty($row))
 {
 	echo"invalid username";
 }
  else
  {
  	$otp=mt_rand(1111,9999);
  	$sql="insert into otp(otp,status)values('$otp','active')";
  	mysqli_query($con,$sql);
    $to=$username;
    $subject='ONE TIME PASSWORD';
    $message='YOUR OTP IS-'.$otp;
    $headers="From:explorad119@gmail.com\r\n";
    if (mail($to, $subject, $message, $headers))
    {
  	?>
  	<script>
  		alert("otp has sent to your email_id");
  		document.location="otp.php";
  	</script>
  	<?php
  }
  else{
    echo"error";
  }
  }
  ?>