<?php
$id=$_GET['id'];
include('dbcon.php');
$sql="delete from product where id='$id'";
mysqli_query($con,$sql);
?>
<script>
	alert("deleted successfully");
	document.location="product_view.php";
</script>