<?php 
session_start();

include('dbcon.php');
$oid=$_SESSION['oid'];
$u=$_SESSION['t1'];
$id=$_GET['id'];
$qty=1;
$price=$_GET['price'];
$brand=$_GET['brand'];

$total=$price;

$k="insert into order_details(cus_id,order_date,pid,order_status,payment_status,delivered_status,pname,qty,unit_price,total,order_no) values('$u',curdate(),'$id','pending','pending','pending','$brand','$qty','$price','$total','$oid')";
	mysqli_query($con,$k);


?>
<script>
alert("Thank you for Order");
document.location="customer_home.php";
</script>
