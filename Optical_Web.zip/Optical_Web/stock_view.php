<?php include('header.php');?>
    
   <h1 align="center"> Stock</h1>

	<table align="center" width="600" border='1'>

		<tr style="background-color:lightgreen;color:white">	
		<td><b>Pid</b></td>
		<td><b>Total_stock</b></td>
		<td><b>Current_stock</b></td>
		<td colspan="2" align="center" style="background-color:red;">action</td>
	</tr>	
<?php
include('dbcon.php');
$sql="select * from stock";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['pid'];?></td>
		<td><?php echo $row['total_stock'];?></td>
		<td><?php echo $row['current_stock'];?></td>
		<td><a href="stock_del.php?id=<?php echo $row['id'];?>"><i class="fa fa-trash" style="color:red"></a></td>
		<td><a href="stock_update.php?id=<?php echo $row['id'];?>"><i class="fa fa-edit" style="color:purple"></a></td>
		</tr>
		<?php
}
?>
</table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>