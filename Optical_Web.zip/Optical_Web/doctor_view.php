<?php include('admin_header.php');?>
    
   <h1 align="center"> Doctor Details </h1>
	<table width="900" border='1' align="center">

		<tr style="background-color:lightgreen;color:white;height:35px;">	
		<td>doctor_name</td>
		<td>specialist_in</td>
		<td>experience</td>
		<td>photo</td>
		<td colspan="2" align="center" style="background-color:red">Action</td>
	</tr>	
<?php
include('dbcon.php');
$sql="select * from doctor";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['doctor_name'];?></td>
		<td><?php echo $row['specialist_in'];?></td>
		<td><?php echo $row['experience'];?></td>
		
		<td><img src="upload/<?php echo $row['photo'];?>" width="100" height="100"></td>
		<td><a href="doctor_del.php?id=<?php echo $row['id'];?>"><i class="fa fa-trash"style="color:red" ></a></td>
		<td><a href="doctor_update.php?id=<?php echo $row['id'];?>"><i class="fa fa-edit" style="color:purple"> </a></td>
		</tr>
		<?php
}
?>
</table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>