<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('admin_header.php');?>
    
   <h1 align="center">Doctor Details</h1>
   <hr>
	
	<style>
	input[type="register"]
	{
		background-color:blue;
	}
</style>
<body bgcolor="pink">

	<form method="post" action="doctor_insert.php" enctype="multipart/form-data">
		<table  align="center" width="500" height="400">

		<tr>
			<td><b>Doctor_name</b></td>
			<td><input type="text"name="d1"required></td>
			</tr>
			<tr>
			<td><b>Specialist_in</b></td>
			<td><input type="text" name="d2"required></td>
			</tr>
			<tr>
				<td><b>Experience</b></td>
				<td><input type="text" name="d3"></td>
			</tr>
		<tr>
			<td><b>Photo</b></td>
			<td><input type="file" name="file"></td>
		</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Add"></td>
			</tr>
			<table>
                      

			 </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>