<?php include('admin_header.php');?>
    
   <h1 align="center">Product</h1>
	<table align="center" width="1100" border='1'>

		<tr style="background-color:lightgreen;color:white;height:35px;">	
		<td><b>Brand_id</b></td>
		<td><b>Gender</b></td>
		<td><b>Frame_color</b></td>
		<td><b>Size</b></td>
		<td><b>Frame_type</b></td>
		<td><b>Frame_shape</b></td>
		<td><b>Frame_material</b></td>
		<td><b>Photo</b></td>
		<td><b>Prize</b></td>
		<td><b>Description</b></td>
		<td><b>Stock</b></td>
		<td><b>Image</b></td>
		
		<td colspan="2" align="center" style="background-color:red;">Action</td>
	</tr>	
<?php
include('dbcon.php');
$sql="select * from product";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['brand_id'];?></td>
		<td><?php echo $row['gender'];?></td>
		<td><?php echo $row['frame_color'];?></td>
		<td><?php echo $row['size'];?></td>
		<td><?php echo $row['frame_type'];?></td>
		<td><?php echo $row['frame_shape'];?></td>
		<td><?php echo $row['frame_material'];?></td>
		<td><?php echo $row['photo'];?></td>
		<td><?php echo $row['prize'];?></td>
		<td><?php echo $row['description'];?></td>
		<td><?php echo $row['stock'];?></td>
		<td><img src="upload/<?php echo $row['photo'];?>" width="100" height="100"></td>
		<td><a href="product_del.php?id=<?php echo $row['id'];?>"><i class="fa fa-trash" style="color:red"> </i> </a></td>
		<td><a href="product_update.php?id=<?php echo $row['id'];?>"><i class="fa fa-edit" style="color:purple"> </i> </a></td>
		</tr>
		<?php
}
?>
</table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>