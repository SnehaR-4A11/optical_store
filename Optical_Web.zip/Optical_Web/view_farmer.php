<?php include('header.php');?>
    
   <h1> Farmer Details </h1>
    <table class="table table-striped">
  <thead class="table-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Farmer Name</th>
      <th scope="col">Village</th>
      <th scope="col">Center Name</th>
      <th scope="col">Contact No</th>
      <th scope="col">Account No</th>
      <th scope="col">IFSC Code</th>
      
      
    </tr>
  </thead>
  <tbody>
    
    <tr>
      <th scope="row">1</th>
      <td>Gururaj</td>
      <td>Dharwad</td>
      <td>xyz</td>
      <td>998012333</td>
      <td>1222</td>
      <td>55555</td>
    </tr>
    
</tbody>
</table>
                                </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>