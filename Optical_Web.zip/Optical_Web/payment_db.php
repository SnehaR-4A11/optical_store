<?php
include('dbcon.php');
$id=$_POST['id'];
$order_id=$_POST['t1'];
$amount=$_POST['a1'];
$payment_date=$_POST['d1'];
$ss="update payment set order_id='$order_id',amount='$amount',payment_date='$payment_date' where id='$id'";
$rs=mysqli_query($con,$ss);
?>
<script>
	alert("Updated Successfully");
	document.location="payment_view.php";
</script>