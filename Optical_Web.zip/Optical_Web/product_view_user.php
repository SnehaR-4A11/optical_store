<?php include('header.php');?>
    
   <h1> Product</h1>
	<table width="400" border='1'>

		<tr style="background-color:blue ;color:red ">	
		<td>brand_id</td>
		<td>gender</td>
		<td>frame_color</td>
		<td>size</td>
		<td>frame_type</td>
		<td>frame_shape</td>
		<td>frame_material</td>
		<td>photo</td>
		<td>prize</td>
		<td>stock</td>
		<td>description</td>
		<td>action</td>
	</tr>	
<?php
include('dbcon.php');
$sql="select * from product";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['brand_id'];?></td>
		<td><?php echo $row['gender'];?></td>
		<td><?php echo $row['frame_color'];?></td>
		<td><?php echo $row['size'];?></td>
		<td><?php echo $row['frame_type'];?></td>
		<td><?php echo $row['frame_shape'];?></td>
		<td><?php echo $row['frame_material'];?></td>
		<td><?php echo $row['photo'];?></td>
		<td><?php echo $row['prize'];?></td>
		<td><?php echo $row['stock'];?></td>
		<td><?php echo $row['description'];?></td>
		<td><img src="upload/<?php echo $row['photo'];?>" width="100" height="100"></td>
		<td><a href="product_del.php?id=<?php echo $row['id'];?>">delete</a></td>
		
		</tr>
		<?php
}
?>
</table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>