<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('header.php');?>
    
   <h1><b>Payment</b></h1>

	<form method="post" action="payment_db.php">
		<?php
		$id=$_GET['id'];
		include('dbcon.php');
		$ss="select * from payment where id='$id' ";
		$rs=mysqli_query($con,$ss);
		$row=mysqli_fetch_array($rs);
		?>
		<table width="300" height="300">
			<input type="hidden" name="id" value="<?php echo $id;?>">
		<tr>
			<td><b>Order_id</b></td>
			<td><input type="text"name="t1"  value="<?php echo $row['order_id'];?>"required>
			</tr>
			<tr>
				<td><b>Amount</b></td>
				<td><input type="text" name="a1"  value="<?php echo $row['amount'];?>" required></td>
			</tr>
			<tr>
			<td><b>Payment_date</b></td>
			<td><input type="text" name="d1"  value="<?php echo $row['payment_date'];?>"required></td>
				</tr>
					<td></td>
				<td><input type="submit"></td>
			</tr>
			<table></table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
			