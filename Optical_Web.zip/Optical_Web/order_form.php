<?php include('header.php');?>
    
   <h1 align="center"><b>Order Details</b></h1>

	<form method="post" action="order_insert.php">
		<table align="center" width="600" height="400"
		<tr>
			<td><b>Customer_id</b></td>
			<td><input type="text" name="t1" required>
			</tr>
			<tr>
				<td><b>Order_date</b></td>
				<td><input type="date" name="c1" required>
			</td>
		</tr>
			<tr>
				<td><b>Pid</b></td>
				<td><input type="text" name="p1" required></td>
			</tr>
			<tr>
			<td><b>Order_status</b></td>
			<td><input type="text"name="o1" required>
			</tr>
			<tr>
				<td><b>payment_status</b></td>
				<td><input type="text" name="r1" required>
			</td>
		</tr>
			<tr>
				<td><b>delivered_status</b></td>
				<td><input type="text" name="q1" required></td>
			</tr>
			<td></td>
				<td><input type="submit"></td>
			</tr>
			<table></table>
				  </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
					