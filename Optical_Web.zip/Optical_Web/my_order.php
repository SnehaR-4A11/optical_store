<?php session_start(); ?>
<?php include('user_header.php');?>
    
   <h1 align="center">My Order</h1>
   <hr>

	<table align="center" width="500" border='1'>

		<tr style="background-color:blue;color:white">

		<td><b>Order No</b></td>	
		
		<td colspan="2" align="center" style="background-color:red;">Action</td>
	</tr>	
<?php

$u=$_SESSION['t1'];

include('dbcon.php');
$sql="select distinct(order_no) from order_details where cus_id='$u'";
//echo $sql;
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	  //$id=$row['id'];
	?>
	<tr>
		<td><?php echo $row['order_no'];?></td>
				
		<td><a href="my_order2.php?id=<?php echo $row['order_no'];?>">View Order</a></td>
		
		
		</tr>
<?php
}
?>
</table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>