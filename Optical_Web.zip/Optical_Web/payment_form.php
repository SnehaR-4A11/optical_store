<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('header.php');?>
    
   <h1 align="center"><b>Payment</b></h1>

	<form method="post" action="payment_insert.php">
		<table  align="center" width="300" height="300">
		<tr>
			<td><b>Order_id</b></td>
			<td><input type="text"name="t1"required></td>
			</tr>
			<tr>
				<td><b>Amount</b></td>
				<td><input type="text" name="a1"></td>
			</tr>
			<tr>
			<td><b>Payment_date</b></td>
			<td><input type="text" name="d1"></td>
				</tr>
					<td></td>
				<td><input type="submit"></td>
			</tr>
			<table></table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
			