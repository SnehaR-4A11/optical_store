<?php
include('dbcon.php');
$doctor_id=$_POST['id'];
$cus_id=$_POST['h2'];
$app_required_date=$_POST['h3'];

$app_timming=$_POST['h5'];
$sql="insert into appointment(doctor_id,cus_id,app_required_date,app_status,app_timming)values('$doctor_id','$cus_id','$app_required_date','pending','$app_timming')";
$rs=mysqli_query($con,$sql);
if($rs)
{
	?>
	 <script>
	 	alert("Appointment has sent successfully");
	 	document.location="appointment.php";
	 </script>
<?php
}
else
{
	echo"not inserted";
}
?>
	