<?php include('admin_header.php');?>
    
   <h1 align="center">Product</h1>
	<table align="center" width="1000" border='1'>

		<tr style="background-color:lightgreen;color:white;height:35px;">	
		<td><b>Frame_type</b></td>
		<td><b>Frame_shape</b></td>
		
		<td><b>Total Stock</b></td>
		<td><b>Remaining Stock</b></td>
		
	</tr>	
<?php
include('dbcon.php');
$sql="select * from product";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		
		<td><?php echo $row['frame_type'];?></td>
		<td><?php echo $row['frame_shape'];?></td>
		<td><?php echo $row['stock'];?></td>
		<td><?php echo $row['remaining_stock'];?></td>
	
		
		</tr>
		<?php
}
?>
</table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>