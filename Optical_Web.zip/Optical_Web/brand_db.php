<?php
include('dbcon.php');
$id=$_POST['id'];
$brandname=$_POST['s1'];
$ss="update brandname set brandname='$brandname' where id='$id'";
$rs=mysqli_query($con,$ss);
?>
<script>
	alert("Updated Successfully");
	document.location="brand_view.php";
</script>