<?php
$con=mysqli_connect("localhost","root","");
$rs=mysqli_select_db($con,"optical");
if(!$rs)
{
	echo"database couldn't  be connected";
}
?>