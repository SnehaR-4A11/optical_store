<?php
session_start();
session_destroy();
?>
<script>
alert("logged out successfully");
document.location="index.html";
</script>