<html>
<body>
	<form method="post" action="forgotpass_con.php">
	<table width="300" height="300">
		<tr>
			<td>User name</td>
			<td><input type="text" name="r1" required></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="forgot password"></td>
		</tr>
	</table></form></body></html>