 <div class="navbar-nav ms-auto p-4 p-lg-0">

                <a href="customer_home.php" class="nav-item nav-link active">Home</a>
                <a href="products_view_cust.php" class="nav-item nav-link">Products</a>

                <a href="my_order.php" class="nav-item nav-link">My Order</a>

                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Appointment</a>
                    <div class="dropdown-menu bg-light m-0">
                        <a href="appointment.php" class="dropdown-item">Take Appointment</a>
                        <a href="appointment_status.php" class="dropdown-item">Appointment Status</a>
                       
                    </div>
                </div>

                  <a href="logout.php" class="nav-item nav-link active">Logout</a>

            </div>