<?php
include('dbcon.php');
$otp=$_POST['r1'];
$ss="select * from otp where otp='$otp'";
$rs=mysqli_query($con,$ss);
$row=mysqli_fetch_array($rs);
if(empty($row))
{
	echo"Invalid otp";
}
else
{
	$sql="update otp set status='inactive' where otp='$otp'";
	mysqli_query($con,$sql);
		?>
		<script>
			alert("otp verification has done successfully");
			document.location="resetpass.php";
		</script>
		<?php
}
?>