<?php
include('dbcon.php');
$id=$_POST['id'];
$doctor_id=$_POST['h1'];
$cus_id=$_POST['h2'];
$app_required_date=$_POST['h3'];
$app_status=$_POST['h4'];
$app_timming=$_POST['h5'];
$ss="update appointment set doctor_id='$doctor_id',cus_id='$cus_id',app_required_date='$app_required_date',app_status='$app_status',app_timming='$app_timming' where id='$id'";
$rs=mysqli_query($con,$ss);
?>
<script>
	alert("Updated Successfully");
	document.location="app_view.php";
</script>