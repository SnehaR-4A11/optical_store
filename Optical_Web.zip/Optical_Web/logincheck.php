<?php
session_start();
include('dbcon.php');
$username=$_POST['t1'];
$password=$_POST['t2'];
$_SESSION['t1']=$username;

$oid=rand(1111,9999);
$_SESSION['oid']=$oid;

$sql="select * from login where username='$username'"; 
$rs=mysqli_query($con,$sql);
$row=mysqli_fetch_array($rs);
if(empty($row))
{
	?>
	<script>
		alert("invalid username");
		document.location="login.html"
	</script>
	<?php
}
else
{
	$upass=$row['password'];
	$utype=$row['usertype'];
	if($password==$upass)
	{
		if($utype=="admin")
		{
		?>
		<script>
			alert("you have logged in as a admin");
			document.location="admin_home.php";
		</script>
		<?php
		}
		if($utype=="doctor")
		{
		?>
		<script>
			alert("you have logged in as a Doctor");
			document.location="doctor_home.php";
		</script>
		<?php
		}
	   if($utype=="customer")
	   {
	   	?>
	   	<script>
	   		alert("you have logged in as customer");
	   		document.location="customer_home.php";
	   	</script>
	   	<?php
	   }
	}
	else
	{
		?>
		<script>
			alert("invalid password");
			document.location="login.html";
		</script>
		<?php
	}
}
?>