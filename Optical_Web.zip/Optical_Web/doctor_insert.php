 <?php
include('dbcon.php');
$doctor_name=$_POST['d1'];
$specialist_in=$_POST['d2'];
$experience=$_POST['d3'];
$photo=$_FILES['file']['name'];
move_uploaded_file($_FILES["file"]["tmp_name"],	"./upload/" . $_FILES["file"]["name"]);	
echo "<div class='sucess'>"."Stored in: " ."./upload/" . $_FILES["file"]["name"]."</div>";
$sql="insert into doctor(doctor_name,specialist_in,experience,photo)values('$doctor_name','$specialist_in','$experience','$photo')";
$rs=mysqli_query($con,$sql);

$pass=rand();
$ss="insert into login(username,password,usertype) values('$doctor_name','$pass','doctor')";
mysqli_query($con,$ss);

if($rs)
{
		?>
	 <script>
	 	alert("inserted successfully");
	 	document.location="doctor_form.php";
	 </script>
<?php
}
else
{
	echo"not inserted";
}
?>
 

	