<?php
include('dbcon.php');
$pid=$_POST['t1'];
$total_stock=$_POST['c1'];
$current_stock=$_POST['p1'];
$sql="insert into stock(pid,total_stock,current_stock)values('$pid','$total_stock','$current_stock')";
$rs=mysqli_query($con,$sql);
if($rs)
{
	echo"inserted successfully";
}
else
{
	echo"not inserted";
}
?>