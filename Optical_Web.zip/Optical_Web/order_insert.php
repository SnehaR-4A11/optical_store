<?php
include('dbcon.php');

$cus_id=$_POST['t1'];
$order_date=$_POST['c1'];
$pid=$_POST['p1'];
$order_status=$_POST['o1'];
$payment_status=$_POST['r1'];
$delivered_status=$_POST['q1'];

$sql="insert into order_details(cus_id,order_date,pid,order_status,payment_status,delivered_status)values('$cus_id','$order_date','$pid','$order_status','$payment_status','$delivered_status')";
$rs=mysqli_query($con,$sql);
if($rs)
{
		?>
	 <script>
	 	alert("inserted successfully");
	 	document.location="order_details.php";
	 </script>
<?php
}
else
{
	echo"not inserted";
}
?>
	