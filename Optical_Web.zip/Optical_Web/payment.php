<?php include('user_header.php');?>
    
   <h1 align="center"><b>Payment</b></h1>
   <?php 
   $id=$_GET['id'];
   $total=$_GET['price'];
   ?>
   <div align="center">
	<form action="../Optical_Web/payment_insert.php" method="POST">
      <input type="hidden" name="amount" value="<?php echo $total;?>">
      <input type="hidden" name="id" value="<?php echo $id;?>">
<script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="rzp_test_8yZuL0JHVhOdQV"
    data-amount="<?php echo $total."00"?>"
    data-buttontext="Pay with Razorpay"
    data-name="Optical"
    data-description="Order Amount"
    data-image=""
    data-prefill.name="Your name"
    data-prefill.email="your email id"
    data-theme.color="#F37254"></script>
   
<input type="hidden" custom="Hidden Element" name="hidden">
</form></div>  </div>
                                
                            </div>
                       
                    <?php include('footer.php');?>
			