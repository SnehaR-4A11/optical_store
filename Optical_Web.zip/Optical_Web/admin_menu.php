<a href="admin_home.php" class="nav-item nav-link active">Home</a>

                 <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Customers</a>
                    <div class="dropdown-menu bg-light m-0">
                        <a href="place_wise_cust.php" class="dropdown-item">Place Wise</a>
                       
                       
                    </div>
                </div>
                
                 
               
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Product</a>
                    <div class="dropdown-menu bg-light m-0">
                        <a href="product_form.php" class="dropdown-item">Add</a>
                        <a href="product_view.php" class="dropdown-item">View</a>
                       
                    </div>
                </div>

                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Doctor</a>
                    <div class="dropdown-menu bg-light m-0">
                        <a href="doctor_form.php" class="dropdown-item">Add</a>
                        <a href="doctor_view.php" class="dropdown-item">View</a>
                       
                    </div>
                </div>

                 <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Report</a>
                    <div class="dropdown-menu bg-light m-0">
                        <a href="payment_view_admin.php" class="dropdown-item">Payment</a>
                        <a href="stocks_report.php" class="dropdown-item">Stocks</a>
                        <a href="order_view_admin.php" class="dropdown-item">Orders</a>
                         <a href="order_view_datewise.php" class="dropdown-item">Date Wise Orders</a>
                       
                    </div>
                </div>

                
                
            </div>
           
           <a href="login.html" class="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block">Logout<i class="fa fa-arrow-right ms-3"></i></a>