<?php include('header.php');?>
    
   <h1 align="center">Order_Details</h1>

	<table align="center" width="900" border='1'>

		<tr style="background-color:lightgreen;color:white">	
		<td><b>Customer_id</b></td>
		<td><b>Order_date</b></td>
		<td><b>Pid</b></td>
		<td><b>Order_status?</b></td>
		<td><b>Payment_status</b></td>
		<td><b>Delivered_status</b></td>
		<td colspan="2" align="center" style="background-color:red;">Action</td>
	</tr>	
<?php
include('dbcon.php');
$sql="select * from order_details";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['cus_id'];?></td>
		<td><?php echo $row['order_date'];?></td>
		<td><?php echo $row['pid'];?></td>
		<td><?php echo $row['order_status'];?></td>
		<td><?php echo $row['payment_status'];?></td>
		<td><?php echo $row['delivered_status'];?></td>
		<td><a href="order_del.php?id=<?php echo $row['id'];?>"><i class="fa fa-trash" style="color:red"></a></td>
		<td><a href="order_update.php?id=<?php echo $row['id'];?>"><i class="fa fa-edit" style="color:purple"></a></td>
		</tr>
		<?php
}
?>
</table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>