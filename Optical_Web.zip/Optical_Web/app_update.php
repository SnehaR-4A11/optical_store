<?php include('doctor_header.php');?>
    
   <h1 align="center"> Appointment </h1>

	<form method="post" action="app_db.php">
		<?php
		$id=$_GET['id'];
		include('dbcon.php');
		$ss="select * from appointment where id='$id' ";
		$rs=mysqli_query($con,$ss);
		$row=mysqli_fetch_array($rs);
		?>
	<table  align="center" width="350" height="350">
    <input type="hidden" name="id" value="<?php echo $id;?>">
		<tr>
		<tr>
			<td><b>Doctor_id</b></td>
			<td><input type="text"name="h1" value="<?php echo $row['doctor_id'];?>" required></td>
			</tr>
			<tr>
			<td><b>Customer_id</b></td>
			<td><input type="text" name="h2" value="<?php echo $row['cus_id'];?>" required></td>
			</tr>
			<tr>
				<td><b>Appointment_required_date</b></td>
				<td><input type="date" name="h3" value="<?php echo $row['app_required_date'];?>" required></td>
			</tr>
		<tr>
			<td><b>Appointment_status</b></td>
			<td><input type="text" name="h4" value="<?php echo $row['app_status'];?>" required></td>
		</tr>
		<tr>
			<td><b>Appointment_timming</b></td>
			<td><input type="text" name="h5" value="<?php echo $row['app_timming'];?>" required></td>
		</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="ok"></td>
			</tr>
		</table>
		  </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>