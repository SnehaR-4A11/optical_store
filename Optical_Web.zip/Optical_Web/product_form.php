<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:green;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('admin_header.php');?>
    
   <h1 align="center"><b>Product</b></h1>
   <hr>
	<form method="post" action="product_insert.php" enctype="multipart/form-data">
		<table align="center" width="750" height="500">
		<tr>
			<td><b>Brand_id</b></td>
			<td><input type="text"name="t1"required></td>
			</tr>
			<tr>
				<td><b>Gender</b></td>
				<td> Male<input type="radio" name="g1" value="male">
					female<input type="radio" name="g1" value="female">
				</td>
			</tr>
			<tr>
				<td><b>Frame_color</b></td>
				<td><input type="text" name="c1"required>
			</td>
		</tr>
		<tr>
			<td><b>Size</b></td>
			<td><select name="s1">
				<option value="small">Small</option>
				<option value="medium">Medium</option>
				<option value="large">Large</option>
			</select></td>
			<td> </td>

		</tr>
		<tr>
			<td><b>Frame_type</b></td>
			
               <td><select name="f1">
			     <option value="rimmed">Rimmed</option>
			     	<option value="Fullrimmed">Full Rimmed</option>
			        <option value="Rimmless">Rimmless</option>
			        <option value="halfrimmed">Half Rimmed</option>
			    </select></td>
			</tr>
			<tr>
				<td><b>Frame_shape</b></td>
				<td><select name="s1">
					<option value="cateye">Cateye</option>
					<option value="rectangle">Rectangle</option>
					<option value="round">Round</option>
				    <option value="geometric">Geometric</option>
				    <option value="hexagonal">Hexagonal</option>
				    <option value="wayfarer">Wayfarer</option></td>
			</tr>
			<tr>
			<td><b>Frame_material</b></td>
			<td><select name="m1">
				<option value="stainlesssteel">Stainlesssteel</option>
				<option value="metal">Metal</option>
				<option value="moldedplastic">Moldedplastic</option>
				<option value="transperent">Transperent</option>
				<option value="gunmetal">Gunmetal</option></td>			
				</tr>
			<tr>
			<td><b>Photo</b></td>
			<td><input type="file" name="file"></td>
			</tr>
				<tr>
				<td><b>Prize</b></td>
				<td><input type="text" name="p1" required></td>
			</tr>
			<tr>
			<td><b>Description</b></td>
			<td><input type="text" name="d1"></td>
				</tr>
				<tr>
					<td><b>Stock</b></td>
					<td><input type="text" name="q1"></td>
				</tr>
					<td></td>
				<td><input type="submit"></td>
			</tr>
			
			<table></table>
			 </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
			