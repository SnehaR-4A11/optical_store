<?php include('header.php');?>
    
   <h1 align="center">Customer Registration</h1>

	<style>
	input[type="register"]
	{
		background-color:blue;
	}
</style>


	<form method="post" action="creg_db.php">
		<?php
		$id=$_GET['id'];
		include('dbcon.php');
		$ss="select * from register where id='$id' ";
		$rs=mysqli_query($con,$ss);
		$row=mysqli_fetch_array($rs);
		?>
		<table  align="center" width="350" height="350">
         <input type="hidden" name="id" value="<?php echo $id;?>">
		<tr>
			<td><b>First_name</b></td>
			<td><input type="text"name="t1" value="<?php echo $row['firstname'];?>"required></td>
			</tr>
			<tr>
			<td><b>Last_name</b></td>
			<td><input type="text" name="t2" value="<?php echo $row['lastname'];?>" required></td>
			</tr>
			<tr>
				<td><b>DOB</b></td>
				<td><input type="date" name="t3" value="<?php echo $row['dob'];?>" required></td>
			</tr>
			<tr>
			<td> <b>City</b> </td>
			
               <td><select name="s1">
			     <option value="dharwad"> Dharwad</option>
			     	<option value="hubli"> Hubli</option>
			        <option value="belgavi"> Belgavi</option>
			    </select></td>
			</tr>
			<tr>
				<td><b>Landmark</b></td>
				<td><input type="text" name="l1" value="<?php echo $row['landmark'];?>"required ></td>
			</tr>
		<tr>
			<td><b>Address</b></td>
			<td> <input type="text" name="a1" value="<?php echo $row['address'];?>" required></td>

		</tr>
		
			<tr>
				<td><b>Pincode</b></td>
				<td><input type="number" name="p1" value="<?php echo $row['pincode'];?>"required></td>
			</tr>
			<tr>
				<td><b>Contact</b></td>
				<td><input type="text" name="c1"  value="<?php echo $row['contact'];?>"required pattern="[6-9]{1}[0-9]{9}" title="enter valid number"></td>
			</tr>
			<tr>
				<td><b>Email</b></td>
				<td><input type="Email" name="e1" value="<?php echo $row['email'];?>"required></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="register"></td>
			</tr>
			<table>
			</div>                 
                            </div>
                        </form>
                    <?php include('footer.php');?>
                 