 <?php
include('dbcon.php');
$id=$_POST['id'];
$doctor_name=$_POST['d1'];
$specialist_in=$_POST['d2'];
$experience=$_POST['d3'];
$photo=$_FILES['file']['name'];
$ss="update doctor set doctor_name='$doctor_name',specialist_in='$specialist_in',experience='$experience',photo='$photo' where id='$id'";
$rs=mysqli_query($con,$ss);
?>
<script>
	alert("Updated Successfully");
	document.location="doctor_view.php";
</script>