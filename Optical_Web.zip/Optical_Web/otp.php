<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	 body
	 {
	 	background-image:url(f1.jpg);
	 	background-repeat:no-repeat;
	 	background-attachment: fixed;
	 	background-size:100%100%;
	 }
	</style>
	<?php include('header.php');?>
    
   <h1> <b>Otp</b> </h1>
	<form method="post" action="otp_con.php">
	<table width="300" height="300">
		<tr>
			<td><b>Enter otp</b></td>
			<td><input type="text" name="r1" required></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" ></td>
		</tr>
	</table>
	</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
			