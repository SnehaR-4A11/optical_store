<?php include('user_header.php');?>
    
   <h1 align="center"><b>Item Qty</b></h1>
   <hr>
   <?php 
   $id=$_GET['id'];
   ?>
	<form method="post" action="send_order_insert.php">
		<input type="hidden" name="id" value="<?php echo $id;?>">
		<table align="center" width="350" height="200">
		<tr>
			<td><b>Enter Qty</b></td>
		<td><input type="number" name="t1" required style="width:200px;"></td>
			</tr>
			
			
			<tr>
				<td></td>
			<td><input type="submit"></td>
			</tr>
			<table>
				</form>
			 </div>
                                
         </div>
         
                        

                    <?php include('footer.php');?>
			