<?php session_start();?>
<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('user_header.php');?>

<?php 
$id=$_GET['id'];

$u=$_SESSION['t1'];
?>
    
   <h1 align="center">Appointment</h1>
   <hr>

	<form method="post" action="app_insert.php">
		<table align="center" width="500" height="450">
			<input type="hidden" name="id" value="<?php echo $id;?>">

		
			<tr>
			<td><b>User Id</b></td>
			<td><input type="text" name="h2"required value="<?php echo $u;?>"></td>
			</tr>
			<tr>
				<td><b>Date</b></td>
				<td><input type="date" name="h3"></td>
			</tr>
		
		<tr>
			<td><b>Timing</b></td>
			<td><input type="text" name="h5"></td>
		</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Ok"></td>
			</tr>
		</table>
		  </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>