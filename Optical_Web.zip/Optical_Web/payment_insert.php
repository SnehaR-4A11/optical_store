<?php
include('dbcon.php');
$id=$_POST['id'];
$amount=$_POST['amount'];
$order_id=rand();

$ss="update order_details set payment_status='Paid',delivered_status='progressing' where order_no='$id'";
mysqli_query($con,$ss);

$sql="insert into payment(order_id,amount,payment_date)values('$id','$amount',curdate())";
$rs=mysqli_query($con,$sql);
if($rs)
{
	?>
	 <script>
	 	alert("Payment has been done successfully");
	 	document.location="my_order.php";
	 </script>
<?php
}
else
{
	echo"Payment Failed";
}
?>
	