<?php
include('dbcon.php');
$id=$_POST['id'];
$pid=$_POST['t1'];
$total_stock=$_POST['c1'];
$current_stock=$_POST['p1'];
$ss="update stock set pid='$pid',total_stock='$total_stock',current_stock='$current_stock' where id='$id'";
$rs=mysqli_query($con,$ss);
?>
<script>
	alert("Updated Successfully");
	document.location="stock_view.php";
</script>