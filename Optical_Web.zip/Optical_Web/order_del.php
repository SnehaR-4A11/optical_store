<?php
$id=$_GET['id'];
include('dbcon.php');
$sql="delete from order_details where id='$id'";
mysqli_query($con,$sql);
?>
<script>
	alert("deleted successfully");
	document.location="my_order.php";
</script>