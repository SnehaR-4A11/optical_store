<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:green;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('admin_header.php');?>
    
   <h1 align="center"> <b>Product</b> </h1>
	<form method="post" action="product_db.php" enctype="multipart/form-data">
		<?php
		$id=$_GET['id'];
		include('dbcon.php');
		$ss="select * from product where id='$id' ";
		$rs=mysqli_query($con,$ss);
		$row=mysqli_fetch_array($rs);
		?>
		<table width="350" height="350" align="center">
			<input type="hidden" name="id" value="<?php echo $id;?>">
		<tr>
			<td><b>Brand_id</b></td>
			<td><input type="text"name="t1" value="<?php echo $row['brand_id'];?>" required>
			</tr>
			<tr>
				<td><b>Gender</b></td>
				<td> Male<input type="radio" name="g1" value="male">
					female<input type="radio" name="g1" value="female">
				</td>
			</tr>
			<tr>
				<td><b>Frame_color</b></td>
				<td><input type="text" name="c1" value="<?php echo $row['frame_color'];?>"required>
			</td>
		</tr>
		<tr>
			<td><b>Size</b></td>
			<td><select name="s1">
				<option value="small">Small</option>
				<option value="medium">Medium</option>
				<option value="large">Large</option>
			</select></td>
			<td> </td>

		</tr>
		<tr>
			<td><b>Frame_type</b></td>
			
               <td><select name="f1">
			     <option value="rimmed">Rimmed</option>
			     	<option value="Fullrimmed">Fullrimmed</option>
			        <option value="Rimmless">Rimmless</option>
			        <option value="Semirimmless">
			    </select></td>
			</tr>
			<tr>
				<td><b>Frame_shape</b></td>
				<td><select name="s1">
					<option value="cateye">Cateye</option>
					<option value="rectangle">Rectangle</option>
					<option value="round">Round</option></td>
			</tr>
			<tr>
			<td><b>Frame_material</b></td>
			<td><select name="m1">
				<option value="stainlesssteel">Stainlesssteel</option>
				<option value="metal">Metal</option>
				<option value="moldedplastic">Moldedplastic</option></td>			
				</tr>
			<tr>
			<td><b>Photo</b></td>
			<td><input type="file" name="file" value="<?php echo $row['photo'];?>"></td>
			</tr>
				<tr>
				<td><b>Prize</b></td>
				<td><input type="text" name="p1" value="<?php echo $row['prize'];?>" required></td>
				<tr>
				<td><b>Stock</b></td>
				<td><input type="text" name="q1" value="<?php echo $row['stock'];?>" required></td>
			</tr>
			<tr>
			<td><b>Description</b></td>
			<td><input type="text" name="d1" value="<?php echo $row['description'];?>"></td>
				</tr>
					<td></td>
				<td><input type="submit"></td>
			</tr>
			<table></table>
			 </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
			