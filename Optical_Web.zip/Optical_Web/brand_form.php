<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('header.php');?>
    
   <h1 align="center"><b>Brand</b></h1>

	<form method="post" action="brand_insert.php ">
		<table  align="center" width="350" height="350">
		<tr>
			<td><b>Brand_name</b></td>
			
               <td><select name="s1">
			     <option value="SRS">SRS</option>
			     	<option value="vencentchase">vencentchase</option>
			        <option value="jacobes">jacobes</option>
			    </select></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Select"></td>
			</tr>
			<table></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
			