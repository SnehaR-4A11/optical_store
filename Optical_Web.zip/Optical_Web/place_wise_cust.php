<?php include('admin_header.php');?>
    
   <h1 align="center">Place Wise Registered Customers</h1>
   <hr>

	<form method="post" action="creg_view.php" enctype="multipart/form-data">
		<table  align="center" width="500" height="400">

		<tr>
			<td><b>Place</b></td>
			<td><select name="t1" required>
				<?php
			   include('dbcon.php');
				$sql="select distinct(city) from register";
				$rs=mysqli_query($con,$sql);
				while($row=mysqli_fetch_array($rs))
				{
				?> 
				<option value="<?php echo $row['city'];?>"> <?php echo $row['city'];?>  </option>

				<?php 
			    }
			    ?>
            </select>
			</td>
			</tr>

		
			<tr>
				<td></td>
				<td><input type="submit" value="View"></td>
			</tr>
			<table>
                      

			 </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>