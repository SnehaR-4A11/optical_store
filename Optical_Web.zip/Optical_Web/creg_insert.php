<?php
include('dbcon.php');
$firstname=$_POST['t1'];
$lastname=$_POST['t2'];
$dob=$_POST['t3'];
$city=$_POST['s1'];
$landmark=$_POST['l1'];
$address=$_POST['a1'];
$pincode=$_POST['p1'];
$contact=$_POST['c1'];
$email=$_POST['e1'];
$password=$_POST['t7'];
$confirmpassword=$_POST['t8'];

$sql="insert into register(firstname,lastname,dob,city,landmark,address,pincode,contact,email)values('$firstname','$lastname','$dob',$city',$landmark','$address','$pincode','$contact','$email')";
$rs=mysqli_query($con,$sql);
$ss="insert into login(username,password,usertype) values('$email','$password','customer')";
mysqli_query($con,$ss);
if($rs)
{
	?>
	 <script>
	 	alert("inserted successfully");
	 	document.location="creg_form.php";
	 </script>
<?php
}
else
{
	echo"not inserted";
}
?>
	