7 <!DOCTYPE html>
<html>
<body>
	<form method="post" action="log_insert.php">
	<table width="300" height="300">
		<tr>
			<td>Username</td>
			<td><input type="text" name="t1" required></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="text" name="t2" required pattern=".{8}" tittle="enter min 8 digits"></td>
		</tr>
		<tr>
			<td>usertype</td>
			<td><input type="text" name="t3" required></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="login"></td>
		</tr>
	</table></form></body></html>