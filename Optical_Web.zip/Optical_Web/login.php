<?php include('header.php');?>
    
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	 body
	 {
	 	background-image:url(new1.jpg);
	 	background-repeat: no-repeat;
	 	background-attachment: fixed;
	 	background-size:100%100%;
	 }
	</style>
</head>
    <body bgcolor="black" text="white">
	<form method="post" action="logincheck.php">
	<h2 align="center">LOGIN ACCOUNT</h2>
	<hr>
	<table  align="center" width="400" height="400">
		<tr>
			<td><b>Username</b></td>
			<td><input type="text" placeholder="enter username"name="t1" required ></td>
		</tr>
		<tr>
			<td><b>Password</b></td>
			<td><input type="password" placeholder="enter password"  name="t2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="must contain atleast one number and one number and one uppercase and lowercase letter, and atleast 8 or more characters" required>
		</tr>
		<tr>
			<td><a href="creg_form.php" style="text-decoration:none;color:blue;"><b>New user?</b></a></td>  
			<td><input type="submit" value="login" ></td>
		</tr>
		</table></form>
		<p align="center" width="300"><a href="forgotpass.php" style="text-decoration:none;color:red;"><b> FORGOT PASSWORD?</b>
		</a></p>
		></div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
			