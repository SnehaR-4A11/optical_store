<?php
$id=$_GET['id'];
include('dbcon.php');
$sql="update order_details set order_status='confirmed' where order_no='$id'";
mysqli_query($con,$sql);
?>
<script>
	alert("Confirmed successfully");
	document.location="my_order.php";
</script>