<?php
$id=$_GET['id'];
include('dbcon.php');
$sql="delete from register where id='$id'";
mysqli_query($con,$sql);
?>
<script>
	alert("deleted successfully");
	document.location="creg_view.php";
</script>