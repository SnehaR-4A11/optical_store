<?php include('admin_header.php');?>
<form>
	<div>
<div>
   <h1>Customer Registration</h1>
   <hr>
	<table width="1000" border="1">
		<tr style="background-color:green;color:white">	
		<td><b>First_name</b></td>
		<td><b>Last_name</b></td>
		<td><b>
		<td><b>City</b></td>
		<td><b>Landmark</b></td>
		<td><b>Address</b></td>
		<td><b>Pincode</b></td>
		<td><b>Contact</b></td>
		<td><b>Email</b></td>
		<!--<td colspan="2" align="center" style="background-color:green;">Action</td>-->
	</tr>	
<?php
include('dbcon.php');
$city=$_POST['t1'];
$sql="select * from register where city='$city'";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['firstname'];?></td>
		<td><?php echo $row['lastname'];?></td>
		<td><?php echo $row['city'];?></td>
		<td><?php echo $row['landmark'];?></td>
		<td><?php echo $row['address'];?></td>
		<td><?php echo $row['pincode'];?></td>
		<td><?php echo $row['contact'];?></td>
		<td><?php echo $row['email'];?></td>
		<!--<td><a href="creg_del.php?id=<?php //echo $row['Id'];?>"><i class="fa fa-trash" style="color:skyblue"></i></a></td>
		<td><a href="creg_update.php?id=<?php //echo $row['Id'];?>"><i class="fa fa-edit"style="color:purple"></i></a></td>-->
		</tr>
		<?php
}
?>
</table>
</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>