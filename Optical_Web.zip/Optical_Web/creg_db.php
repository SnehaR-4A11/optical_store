<?php
include('dbcon.php');
$id=$_POST['id'];
$firstname=$_POST['t1'];
$lastname=$_POST['t2'];
$city=$_POST['s1'];
$landmark=$_POST['l1'];
$address=$_POST['a1'];
$pincode=$_POST['p1'];
$contact=$_POST['c1'];
$email=$_POST['e1'];
$ss="update register set firstname='$firstname',lastname='$lastname',city='$city',landmark='$landmark',address='$address',pincode='$pincode',contact='$contact',email='$email' where id='$id' ";
$rs=mysqli_query($con,$ss);
?>
<script>
	alert("Updated Successfully");
	document.location="creg_view.php";
</script>