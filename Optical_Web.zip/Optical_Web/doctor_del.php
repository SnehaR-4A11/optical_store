<?php
$id=$_GET['id'];
include('dbcon.php');
$sql="delete from doctor where id='$id'";
mysqli_query($con,$sql);
?>
<script>
	alert("deleted successfully");
	document.location="doctor_view.php";
</script>