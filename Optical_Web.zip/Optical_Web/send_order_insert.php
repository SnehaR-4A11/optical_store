<?php 
session_start();

include('dbcon.php');
$oid=$_SESSION['oid'];
$u=$_SESSION['t1'];
$id=$_POST['id'];
$qty=$_POST['t1'];

$ss="select * from product where id='$id'";
$rs=mysqli_query($con,$ss);
$row=mysqli_fetch_array($rs);
$price=$row['prize'];
$brand=$row['brand_id'];

$total=$price*$qty;
$stock=$row['stock'];
if($qty<=$stock)
{
    $rstock=$stock-$qty;

    $m="update product set remaining_stock='$rstock' where id='$id'";
    mysqli_query($con,$m);


	$k="insert into order_details(cus_id,order_date,pid,order_status,payment_status,delivered_status,pname,qty,unit_price,total,order_no) values('$u',curdate(),'$id','pending','pending','pending','$brand','$qty','$price','$total','$oid')";
	mysqli_query($con,$k);

	//echo $k;

?>
<script>
//alert("Thank you for Order Confirmation");
document.location="choose_lens.php";
</script>
<?php
}
else
{
	?>
<script>
	alert("Sorry..! Insufficient Stock");
	document.location="products_view_cust.php";
</script>
	<?php

}
?>