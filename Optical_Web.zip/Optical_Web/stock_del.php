<?php
$id=$_GET['id'];
include('dbcon.php');
$sql="delete from stock where id='$id'";
mysqli_query($con,$sql);
?>
<script>
	alert("deleted successfully");
	document.location="stock_view.php";
</script>