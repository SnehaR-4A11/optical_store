<?php
include('dbcon.php');
$brand_id=$_POST['t1'];
$gender=$_POST['g1'];
$frame_color=$_POST['c1'];
$size=$_POST['s1'];
$frame_type=$_POST['f1'];
$frame_shape=$_POST['s1'];
$frame_material=$_POST['m1'];
$photo=$_FILES['file']['name'];
$prize=$_POST['p1'];
$stock=$_POST['q1'];
$description=$_POST['d1'];

move_uploaded_file($_FILES["file"]["tmp_name"],	"./upload/" . $_FILES["file"]["name"]);	
echo "<div class='sucess'>"."Stored in: " ."./upload/" . $_FILES["file"]["name"]."</div>";

$sql="insert into product(brand_id,gender,frame_color,size,frame_type,frame_shape,frame_material,photo,prize,stock,description)values('$brand_id','$gender','$frame_color','$size','$frame_type','$frame_shape','$frame_material','$photo','$prize','$stock','$description')";
$rs=mysqli_query($con,$sql);
if($rs)
{
	?>
	<script>
	 alert("inserted successfully");
	 document.location="product_form.php";
	</script>
	<?php
}
else
{
	echo"not inserted";
}
?>