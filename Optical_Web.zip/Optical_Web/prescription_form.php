<html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('header.php');?>
    
   <h1 align="center">Add prescription</h1>
	
	<style>
	input[type="register"]
	{
		background-color:blue;
	}
</style>
<body bgcolor="pink">

	<form method="post" action="pre_insert.php">
		<table  align="center" width="300" height="300">

		<tr>
				<td><b>REYE</b></td>
				<td><input type="text" name="d1" required></td>
				</td>
			</tr>
			<tr>
			<td><b>SPH</b></td>
			<td><input type="text" name="d2"required></td>
			</tr>
			<tr>
				<td><b>CYL</b></td>
				<td><input type="text" name="d3"></td>
			</tr>
		<tr>
			<td><b>AXIS</b></td>
			<td><input type="text" name="d4"></td>
		</tr>
		<tr>
			<td><b>VD</b></td>
			<td><input type="text" name="d5"required></td>
			</tr>
			<tr>
				<td><b>Near Add</b></td>
				<td><input type="text" name="d6"></td>
			</tr>
		<tr>
			<td><b>VN</b></td>
			<td><input type="text" name="d7"></td>
		</tr>
		
			<tr>
				<td></td>
				<td><input type="submit" value="Book"></td>
			</tr>
			<table>
                      

			 </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>
                    <html>
<body>
	<style>
	 input[type="submit"]
	 {
	 	background-color:lightgreen;
	 	width:200px;
	 	border:none;
	 	border-radius:4px;
	 	color:white;
	 	font-weight:bold;
	 	font-size:16px;
	 	height:30px;
	 }
	 input[type="text"]
	 {
	  width:200px;
	 }
	</style>
<?php include('header.php');?>
    
   <h1 align="center">Add prescription</h1>
	
	<style>
	input[type="register"]
	{
		background-color:blue;
	}
</style>
<body bgcolor="pink">

	<form method="post" action="pre_insert.php">
		<table  align="center" width="300" height="300">

		<tr>
				<td><b>LEYE</b></td>
				<td><input type="text" name="d1" required></td>
				</td>
			</tr>
			<tr>
			<td><b>SPH</b></td>
			<td><input type="text" name="d2"required></td>
			</tr>
			<tr>
				<td><b>CYL</b></td>
				<td><input type="text" name="d3"></td>
			</tr>
		<tr>
			<td><b>AXIS</b></td>
			<td><input type="text" name="d4"></td>
		</tr>
		<tr>
			<td><b>VD</b></td>
			<td><input type="text" name="d5"required></td>
			</tr>
			<tr>
				<td><b>Near Add</b></td>
				<td><input type="text" name="d6"></td>
			</tr>
		<tr>
			<td><b>VN</b></td>
			<td><input type="text" name="d7"></td>
		</tr>
		
			<tr>
				<td></td>
				<td><input type="submit" value="Book"></td>
			</tr>
			<table>
                      

			 </div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>