<?php 
include('dbcon.php');
$request_id=$_POST['h2'];
$cust_id=$_POST['h3'];
$RE_SPH=$_POST['h'];
$LE_SPH=$_POST['h9'];
$RE_CYL=$_POST['h4'];
$LE_CYL=$_POST['h10'];
$RE_AXIS=$_POST['h5'];
$LE_AXIS=$_POST['h11'];
$RE_VD=$_POST['h6'];
$LE_VD=$_POST['h12'];
$RE_NEAR_ADD=$_POST['h7'];
$LE_NEAR_ADD=$_POST['h13'];
$RE_VN=$_POST['h8'];
$LE_VN=$_POST['h14'];

$ss="insert into add_prescription(request_id,cust_id,RE_SPH,LE_SPH,RE_CYL,LE_CYL,RE_AXIS,LE_AXIS,RE_VD,LE_VD,RE_NEAR_ADD,LE_NEAR_ADD,RE_VN,LE_VN)values('$request_id','$cust_id','$RE_SPH','$LE_SPH','$RE_CYL','$LE_CYL','$RE_AXIS','$LE_AXIS','$RE_VD','$LE_VD','$RE_NEAR_ADD','$LE_NEAR_ADD','$RE_VN','$LE_VN')";

mysqli_query($con,$ss);

?>
<script>
	alert("Added Successfully");
	document.location="doctor_home.php";
</script>