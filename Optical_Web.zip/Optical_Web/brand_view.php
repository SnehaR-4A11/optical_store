<?php include('header.php');?>
    
   <h1 align="center">Brand</h1>
	<table align="center" width="400" border='1'>

		<tr style="background-color:lightgreen;color:white ">	
		<td align="center"><b>Brand_name</b></td>
		<td colspan="2" align="center" style="background-color:red;">Action</td>
	</tr>	
<?php
include('dbcon.php');
$sql="select * from brandname";
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	?>
	<tr>
		<td><?php echo $row['brandname'];?></td>
		<td><a href="brand_del.php?id=<?php echo $row['id'];?>"><i class="fa fa-trash" style="color:red"></a></td>
		<td><a href="brand_update.php?id=<?php echo $row['id'];?>"> <i class="fa fa-edit" style="color:purple"></a></td>"
		</tr>
		<?php
}
?>
</table>
</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>