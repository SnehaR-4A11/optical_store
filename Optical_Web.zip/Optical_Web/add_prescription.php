<?php include('doctor_header.php');?>
 
   <h1 align="center">Appointment</h1>
   <hr>
	<form method="post" action="prescription_insert.php">
		<table align="center" width="706" height="277">
			
		  <tr>
			<td height="70"><b>Request Id</b></td>
			<td colspan="6"><input type="text" name="h2"required="required" value="<?php echo $_GET['id'];?>" /></td>
			</tr>

			<tr>
				<td height="32"><b>Customer Id</b></td>
			    <td colspan="6"><input type="text" name="h3" value="<?php echo $_GET['u'];?>" /></td>
	        </tr>
		
		<tr>
			<td height="42" colspan="7"><b>SpectaCle Prescription</b></td>
		    </tr>
			<tr>
				<td>EYE</td>
				<td>SPH</td>
				<td>CYL</td>
				<td>AXIS</td>
				<td>VD</td>
				<td>Near Add</td>
				<td>VN</td>
			</tr>
			<tr>
			  <td>RE</td>
			  <td><input name="h" type="text" size="12" /></td>
			  <td><input name="h4" type="text" size="15" /></td>
			  <td><input name="h5" type="text" size="15" /></td>
			  <td><input name="h6" type="text" size="15" /></td>
			  <td><input name="h7" type="text" size="15" /></td>
			  <td><input name="h8" type="text" size="15" /></td>
		  </tr>
			<tr>
			  <td>LE</td>
			  <td><input name="h9" type="text" size="12" /></td>
			  <td><input name="h10" type="text" size="15" /></td>
			  <td><input name="h11" type="text" size="15" /></td>
			  <td><input name="h12" type="text" size="15" /></td>
			  <td><input name="h13" type="text" size="15" /></td>
			  <td><input name="h14" type="text" size="15" /></td>
		  </tr>

		  <tr><td></td>
		  <td> </td>
		  <td> <input type="submit" class="btn btn-primary"></td>  </tr>
		</table>
</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>