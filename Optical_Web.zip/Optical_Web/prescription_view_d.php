<?php session_start(); ?>
<?php include('doctor_header.php');?>
    
   <h1 align="center">Prescription Details</h1>
   <hr>

	<table align="center" width="1113" border='1'>

		<tr style="background-color:blue;color:white">

		<td height="31"><b>Customer Id</b></td>
		<td><b>RE SPH</b></td>
		<td><strong>LE SPH</strong></td>
		<td><strong>RE CYL</strong></td>
		<td><strong>LE CYL</strong></td>
		<td><strong>RE AXIS</strong></td>
		<td><strong>LE AXIS</strong></td>
		<td><strong>RE VD</strong></td>
		<td><strong>LE VD</strong></td>
		<td><strong>RE NEAR ADD</strong></td>
		<td><strong>LE NEAR ADD</strong></td>
		<td><strong>RE VN</strong></td>
		<td><strong>LE VN</strong></td>
	  </tr>	
<?php

include('dbcon.php');
$sql="select * from add_prescription";
//echo $sql;
$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rs))
{
	  //$id=$row['id'];
	?>
	<tr>
		<td><?php echo $row['cust_id'];?></td>
		<td><?php echo $row['RE_SPH'];?></td>
		<td><?php echo $row['LE_SPH'];?></td>
		<td><?php echo $row['RE_CYL'];?></td>
		<td><?php echo $row['LE_CYL'];?></td>
		<td><?php echo $row['RE_AXIS'];?></td>
		<td><?php echo $row['LE_AXIS'];?></td>
		<td><?php echo $row['RE_VD'];?></td>
		<td><?php echo $row['LE_VD'];?></td>
		<td><?php echo $row['RE_NEAR_ADD'];?></td>
		<td><?php echo $row['LE_NEAR_ADD'];?></td>
		<td><?php echo $row['RE_VN'];?></td>
		<td><?php echo $row['LE_VN'];?></td>
		</tr>
<?php
}
?>
</table>
</div>
                                
                            </div>
                        </form>
                    <?php include('footer.php');?>